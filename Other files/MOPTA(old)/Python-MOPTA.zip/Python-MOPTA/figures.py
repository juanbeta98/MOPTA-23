# -*- coding: utf-8 -*-
"""
Created on Fri Jul 23 15:42:21 2021

@author: Daniel
"""

#Important packages
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import numpy as np
import decimal
from matplotlib.pyplot import *


##### Performance #####

data =pd.read_csv("C:/Users/Daniel/Documents/Universidad de los Andes/MOPTA/Experiment2.txt",
                  names = ["Configuration", "customers", "c_f" , "c_o", "c_t", "FixedCost", "OvertimeCost", "TravelTimeCost", "Z_IP", "routes", "time"])


my_pal = {"A": "steelblue", "B": "darkgray", "C": "indianred"}

fig, ax = plt.subplots()
sns_plot = sns.boxplot(y='routes', x='customers', 
                 data=data, hue = 'Configuration', palette=my_pal, ax = ax)
#ax.set_yscale('log')
plt.ylabel("Number of routes")
plt.xlabel("Number of customers")
leg = plt.legend()
plt.tight_layout()
plt.savefig('C:/Users/Daniel/Documents/Universidad de los Andes/MOPTA/Figuras y Tablas/Sensibility/CostsRoutes.pdf')


fig, ax = plt.subplots()
sns_plot = sns.boxplot(y='time', x='customers', 
                 data=data, hue = 'Configuration', palette=my_pal, ax = ax)
#ax.set_yscale('log')
plt.ylabel("CPU time (seconds)")
plt.xlabel("Number of customers")
leg = plt.legend()
plt.tight_layout()
plt.savefig('C:/Users/Daniel/Documents/Universidad de los Andes/MOPTA/Figuras y Tablas/Sensibility/CostsTime.pdf')


##### Sensibility #####

data =pd.read_csv("C:/Users/Daniel/Documents/Universidad de los Andes/MOPTA/Experiment2(alpha-details).txt",
                  names = ["Configuration", "customers", "difference"])

my_pal = {"A-B": "steelblue", "A-C": "darkgray", "B-C": "indianred"}

fig, ax = plt.subplots()
sns_plot = sns.boxplot(y='difference', x='customers', 
                 data=data, hue = 'Configuration', palette=my_pal, ax = ax)
#ax.set_yscale('log')
plt.ylabel("Average difference")
plt.xlabel("Number of customers")
leg = plt.legend()
plt.tight_layout()
plt.savefig('C:/Users/Daniel/Documents/Universidad de los Andes/MOPTA/Figuras y Tablas/Sensibility/AlphaAppointment.pdf')


data_time =pd.read_csv("C:/Users/Daniel/Documents/Universidad de los Andes/MOPTA/Experiment2(alpha).txt",
                  names = ["Configuration", "customers", "alpha", "time"])

my_pal = {"A": "steelblue", "B": "darkgray", "C": "indianred"}
fig, ax = plt.subplots()
sns_plot = sns.boxplot(y='time', x='customers', 
                 data=data_time, hue = 'Configuration', palette=my_pal, ax = ax)
#ax.set_yscale('log')
plt.ylabel("CPU time (seconds)")
plt.xlabel("Number of customers")
leg = plt.legend()
plt.tight_layout()
plt.savefig('C:/Users/Daniel/Documents/Universidad de los Andes/MOPTA/Figuras y Tablas/Sensibility/AlphaTime.pdf')
