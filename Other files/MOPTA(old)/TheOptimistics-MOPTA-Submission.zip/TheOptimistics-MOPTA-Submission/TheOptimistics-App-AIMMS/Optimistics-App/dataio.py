import json

def dataFromDict(dic:dict):
    """ takes the request.get_json dictionary and returns the input for the H-SARA problem"""

    data = dic

    maxTime = int(data['maxTime'])
    costFixed = data['costFixed']
    costTime = data['costTime']
    costOvertime = data['costOvertime']
    alpha = data['alpha']
    t_max = data['runningTime']
    mean_service_time = data['serviceTime']
    randomInstance = data['RamdonInstance']
    numCustomers = int(data['numCustomers'])
    lat = data['latitude']
    lon = data['longitude']
    
    return maxTime, costFixed, costTime, costOvertime, alpha, t_max, mean_service_time,randomInstance, numCustomers, lat, lon